#if __VERSION__ >= 130
#define attribute in
#define varying out
#endif

attribute vec4 a_position;
attribute vec2 a_texcoord0;

varying vec2 v_texcoord0;

const float X_SCALE = 1.258;

void main() {
	v_texcoord0 = a_texcoord0;
	gl_Position = vec4(a_position.x * X_SCALE, a_position.yzw);
}