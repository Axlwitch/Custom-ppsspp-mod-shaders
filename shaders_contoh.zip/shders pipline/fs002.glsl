#version 320 es
#extension GL_EXT_shader_framebuffer_fetch : require
// Driver: PowerVR Rogue GE8320 - GLSL 320
#define DISCARD discard
precision mediump float;
precision highp int;
#define splat3(x) vec3(x)
#define mul(x, y) ((x) * (y))
// %00060000:00000102 Tex(TFuncMod) Fog
uniform sampler2D tex;
uniform vec2 u_texNoAlphaMul;
in lowp vec4 v_color0;
uniform vec3 u_fogcolor;
in highp float v_fogdepth;
in highp vec3 v_texcoord;
in highp vec4 v_1;
in highp vec4 v_2;
in highp vec4 v_3;
in highp vec4 v_4;
flat in mediump int flag;
uniform highp float u_time;
uniform highp float u_near;
uniform highp float u_far;

// ===================== TUNING (hanya flag == 1) =====================
#define NORMAL_BLEND     1.0
#define NORMAL_Y_SIGN    1.0
#define SPHERE_FLIP_Y    0      // 1 jika pantulan terbalik atas-bawah
#define SPHERE_ORIG      0      // 1 = rumus referensi Cina, 0 = rumus baku
#define MATCAP_EXPOSURE  2.4
#define MATCAP_MIX       1.0
#define MATCAP_CONTRAST  0.8  // pertajam beda terang-gelap matcap
#define SPEC_GAIN        0.30
#define BASE_GAIN        1.25
#define CAVITY_DARK      0.9
#define GOLD_GAIN        1.60
#define GOLD_BASE_DARK   0.60
#define FLOW_FREQ        18.0
#define FLOW_MIX         0.45
#define GREEN_LO         0.06
#define GREEN_HI         0.28
#define MARK_SIZE_MIN    16
// =====================================================================

highp vec3 getFxNormal() {
  highp vec3 nV = cross(dFdx(v_3.xyz), dFdy(v_3.xyz));
  if (flag == 1) {
    highp float l1 = dot(v_1.xyz, v_1.xyz);
    return l1 > 0.0 ? v_1.xyz * inversesqrt(l1) : vec3(0.0, 0.0, 1.0);
  }
  if (dot(nV, v_3.xyz) > 0.0) nV = -nV;
  highp float l2 = dot(nV, nV);
  return l2 > 0.0 ? nV * inversesqrt(l2) : vec3(0.0, 0.0, 1.0);
}
highp float getFarBlur() {
  if (flag != 2) return 0.0;
  return smoothstep(u_near, u_far, abs(v_3.z));
}

// ---- penanda: kotak biru ~10x10 px di tengah texture ----
bool isBlue(vec3 c) { return c.r < 0.1 && c.g < 0.1 && c.b > 0.8; }
bool hasMarker() {
  ivec2 sz = textureSize(tex, 0);
  if (min(sz.x, sz.y) < MARK_SIZE_MIN) return false;
  ivec2 c = sz / 2;
  return isBlue(texelFetch(tex, c + ivec2(-3, -3), 0).rgb) &&
         isBlue(texelFetch(tex, c + ivec2( 3,  3), 0).rgb);
}

highp vec2 quadUV(highp vec2 uv, highp vec2 origin) {
  highp vec2 h = 0.5 / vec2(textureSize(tex, 0));
  return clamp(fract(uv) * 0.5, h, 0.5 - h) + origin;
}

// kuadran kiri-bawah dibaca tanpa filter agar selektor tidak tercampur
vec4 commandTexel(highp vec2 uv) {
  ivec2 sz = textureSize(tex, 0);
  ivec2 hs = sz / 2;
  ivec2 p = clamp(ivec2(fract(uv) * vec2(hs)), ivec2(0), hs - ivec2(1));
  return texelFetch(tex, p + ivec2(0, hs.y), 0);
}

// peta bola (view space): u = arah pandang, n = normal
highp vec2 sphereUV(highp vec3 u, highp vec3 n) {
  highp vec3 r = reflect(u, n);
#if SPHERE_ORIG
  highp float m = 2.0 * sqrt(max(r.x * r.x + r.y * r.y + (r.z + 1.0) * r.z, 1e-8));
#else
  highp float m = 2.0 * sqrt(max(r.x * r.x + r.y * r.y + (r.z + 1.0) * (r.z + 1.0), 1e-8));
#endif
#if SPHERE_FLIP_Y
  return vec2(r.x / m + 0.5, 0.5 - r.y / m);
#else
  return vec2(r.x / m + 0.5, r.y / m + 0.5);
#endif
}

highp vec3 applyNormalMap(highp vec3 N, highp vec3 dp1, highp vec3 dp2, highp vec2 duv1, highp vec2 duv2, highp vec3 nm) {
  highp vec3 dp2perp = cross(dp2, N);
  highp vec3 dp1perp = cross(N, dp1);
  highp vec3 T = dp2perp * duv1.x + dp1perp * duv2.x;
  highp vec3 B = dp2perp * duv1.y + dp1perp * duv2.y;
  highp float inv = inversesqrt(max(max(dot(T, T), dot(B, B)), 1e-12));
  highp vec3 Nm = normalize(T * (nm.x * inv) + B * (nm.y * inv * NORMAL_Y_SIGN) + N * nm.z);
  return normalize(mix(N, Nm, NORMAL_BLEND));
}

vec3 softClip(vec3 c) {
  vec3 over = max(c - 0.8, 0.0);
  return min(c, vec3(0.8)) + 0.2 * (1.0 - exp(-over * 5.0));
}

out vec4 fragColor0;
void main() {
  highp vec2 uv = v_texcoord.xy;
  highp vec2 dx = dFdx(uv);
  highp vec2 dy = dFdy(uv);
  highp vec3 dp1 = dFdx(v_3.xyz);
  highp vec3 dp2 = dFdy(v_3.xyz);
  bool atlas = (flag == 1) && hasMarker();
  highp float nl = dot(v_1.xyz, v_1.xyz);
  highp vec3 N0 = nl > 0.0 ? v_1.xyz * inversesqrt(nl) : vec3(0.0, 0.0, 1.0);

  vec4 t;
  vec4 cmd = vec4(0.0);
  vec4 maskTex = vec4(0.0);
  vec3 nmv = vec3(0.0, 0.0, 1.0);
  highp vec3 N = vec3(0.0, 0.0, 1.0);

  if (atlas) {
    t = textureGrad(tex, quadUV(uv, vec2(0.0, 0.0)), dx * 0.5, dy * 0.5);
    nmv = textureGrad(tex, quadUV(uv, vec2(0.5, 0.0)), dx * 0.5, dy * 0.5).rgb * 2.0 - 1.0;
    cmd = commandTexel(uv);
    maskTex = textureGrad(tex, quadUV(uv, vec2(0.0, 0.5)), dx * 0.5, dy * 0.5);
    N = applyNormalMap(N0, dp1, dp2, dx, dy, nmv);
  } else {
    t = texture(tex, uv);   // jalur asli, tidak diubah
  }

  vec4 p = v_color0;
  t.a = max(t.a, u_texNoAlphaMul.x);
  vec4 v = p * t;
  v.rgb = clamp(v.rgb * u_texNoAlphaMul.y, 0.0, 1.0);

  if (atlas) {
    v.rgb *= BASE_GAIN;

    // selektor = kanal R kuadran kiri-bawah:
    //   r < 0.1       -> tanpa pantulan
    //   0.1 .. 0.5    -> peta bola 0..3 (tiap 0.1)
    int idx = int(floor(cmd.r * 10.0 + 0.02)) - 1;

    if (idx >= 0) {
      idx = min(idx, 3);
      highp vec2 origin = vec2(0.5 + 0.25 * float(idx & 1), 0.5 + 0.25 * float(idx >> 1));
      highp vec2 su = clamp(sphereUV(normalize(v_3.xyz), N), 0.02, 0.98);
      vec3 sm = textureLod(tex, origin + su * 0.25, 0.0).rgb;

      float cav = mix(1.0, CAVITY_DARK, smoothstep(0.15, 0.65, length(nmv.xy)));

      // kontras di sekitar tengah supaya sapuan pantulan terlihat saat bergerak
      vec3 sc = clamp((sm - 0.5) * MATCAP_CONTRAST + 0.5, 0.0, 1.5);
      vec3 lit = sc * MATCAP_EXPOSURE;
      vec3 shade = mix(vec3(1.0), lit, MATCAP_MIX);
      v.rgb = v.rgb * shade * cav;

      // specular tajam + fresnel tepi
      float lum = dot(sm, vec3(0.299, 0.587, 0.114));
      float fres = pow(1.0 - clamp(dot(N, -normalize(v_3.xyz)), 0.0, 1.0), 3.0);
      v.rgb += SPEC_GAIN * pow(lum, 2.5) + fres * 0.15 * sm;
    }

    // emisif gold: mask hijau (kanal R dipakai selektor, jadi gold harus R ~ 0)
    float gdom = maskTex.g - max(maskTex.r, maskTex.b);
    float gm = smoothstep(GREEN_LO, GREEN_HI, gdom);
    float pulse = 0.5 + 0.5 * sin(u_time * 4.0);
    float flow = 0.5 + 0.5 * sin(u_time * 3.0 - (uv.x + uv.y) * FLOW_FREQ);
    float energy = 0.35 + 0.65 * mix(pulse, flow, FLOW_MIX);
    float shift = smoothstep(0.7, 0.95, pulse);
    vec3 gcol = mix(vec3(1.2, 0.95, 0.2), vec3(0.95, 0.15, 0.1), shift);
    v.rgb = mix(v.rgb, v.rgb * GOLD_BASE_DARK, gm);
    v.rgb += gcol * energy * gm * GOLD_GAIN * (0.5 + 0.5 * maskTex.g);

    v.rgb = softClip(v.rgb);
  }

  float fogCoef = clamp(v_fogdepth, 0.0, 1.0);
  v.rgb = mix(u_fogcolor, v.rgb, fogCoef);
  fragColor0 = v;
}