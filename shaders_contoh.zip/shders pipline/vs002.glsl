#version 320 es
// Driver: PowerVR Rogue GE8320 - GLSL 320
precision highp float;
#define gl_VertexIndex gl_VertexID
#define splat3(x) vec3(x)
#define mul(x, y) ((x) * (y))
// [MODEL]
// %0001c000:0100030e HWX N T MatUp:3 Light: 0: c:0 t:0 1: c:0 t:0 2: c:0 t:0 
in vec3 position;
in highp vec3 normal;
in vec2 texcoord;
uniform vec4 u_xywh;
uniform float u_NaN;
uniform vec2 u_minZmaxZ;
uniform vec2 u_rasterOffset;
uniform vec3 u_vpScale;
uniform vec3 u_vpOffset;
uniform mat4 u_proj_lens;
uniform mat4 u_proj;
uniform mat4 u_world;
uniform mat4 u_view;
uniform vec4 u_uvscaleoffset;
uniform vec3 u_lightpos0;
uniform lowp vec3 u_lightambient0;
uniform lowp vec3 u_lightdiffuse0;
uniform vec3 u_lightpos1;
uniform lowp vec3 u_lightambient1;
uniform lowp vec3 u_lightdiffuse1;
uniform vec3 u_lightpos2;
uniform lowp vec3 u_lightambient2;
uniform lowp vec3 u_lightdiffuse2;
uniform lowp vec4 u_ambient;
uniform lowp vec3 u_matdiffuse;
uniform lowp vec4 u_matspecular;
uniform lowp vec3 u_matemissive;
uniform lowp float u_scaleX;
uniform lowp float u_scaleY;
uniform lowp vec4 u_matambientalpha;
uniform highp vec2 u_fogcoef;
uniform highp float u_time;
out lowp vec4 v_color0;
out mediump vec3 v_texcoord;
out mediump float v_fogdepth;
out highp vec4 v_1;
out highp vec4 v_2;
out highp vec4 v_3;
out highp vec4 v_4;
flat out mediump int flag;
vec3 normalizeOr001(vec3 v) {
   float len2 = dot(v, v);
   return len2 == 0.0 ? vec3(0.0, 0.0, 1.0) : (v * inversesqrt(len2));
}
void main() {
  bool zClipped = false;
  vec3 worldpos = mul(vec4(position, 1.0), u_world).xyz;
  mediump vec3 worldnormal = normalizeOr001(mul(vec4(normal, 0.0), u_world).xyz);
  vec4 viewPos = vec4(mul(vec4(worldpos, 1.0), u_view).xyz, 1.0);
  highp vec3 fxRawN = normal;
  highp mat3 fxW = mat3(u_world);
  highp mat3 fxNM = mat3(cross(fxW[1], fxW[2]), cross(fxW[2], fxW[0]), cross(fxW[0], fxW[1]));
  highp vec3 fxNormal = normalizeOr001(fxNM * fxRawN);
  if (dot(fxW[0], fxNM[0]) < 0.0) fxNormal = -fxNormal;
  v_1 = vec4(normalizeOr001(mul(vec4(worldnormal, 0.0), u_view).xyz), 0.0);// view space untuk fix efek yang perlu rotasi kamera(rim dll)
  v_2 = vec4(worldpos, 1.0);
  v_3 = vec4(viewPos.xyz, 0.0);
  v_4 = vec4(0.0);
  
  vec4 outPos = mul(u_proj_lens, viewPos);
  vec4 orgPos = mul(u_proj, viewPos);
  if (outPos.z < -outPos.w) {
    zClipped = true;
  }
  float recip = 1.0 / outPos.w;
  outPos.xyz = (outPos.xyz * u_vpScale.xyz) * recip + u_vpOffset.xyz;
  vec4 ambientColor = u_matambientalpha;
  vec3 diffuseColor = u_matdiffuse.rgb;
  vec3 specularColor = u_matspecular.rgb;
  lowp vec4 lightSum0 = u_ambient * ambientColor + vec4(u_matemissive, 0.0);
  vec3 toLight;
  lowp vec3 diffuse;
  mediump float ldot;
  toLight = u_lightpos0;
  ldot = dot(toLight, worldnormal);
  diffuse = (u_lightdiffuse0 * diffuseColor) * max(ldot, 0.0);
  lightSum0.rgb += (u_lightambient0 * ambientColor.rgb + diffuse);
  toLight = u_lightpos1;
  ldot = dot(toLight, worldnormal);
  diffuse = (u_lightdiffuse1 * diffuseColor) * max(ldot, 0.0);
  lightSum0.rgb += (u_lightambient1 * ambientColor.rgb + diffuse);
  toLight = u_lightpos2;
  ldot = dot(toLight, worldnormal);
  diffuse = (u_lightdiffuse2 * diffuseColor) * max(ldot, 0.0);
  lightSum0.rgb += (u_lightambient2 * ambientColor.rgb + diffuse);
  v_color0 = clamp(lightSum0, 0.0, 1.0);
  v_texcoord = vec3(texcoord.xy * u_uvscaleoffset.xy, 0.0);
  v_fogdepth = (viewPos.z + u_fogcoef.x) * u_fogcoef.y;
  outPos.xy -= u_rasterOffset.xy;
  outPos.xy = (((outPos.xy + u_xywh.xy) * u_xywh.zw) - vec2(1.0, 1.0)) * outPos.w;
  outPos.z *= outPos.w * (1.0 / 65536.0);
  gl_Position = outPos;
  gl_Position.z = orgPos.z / abs(orgPos.w) * abs(outPos.w);
  gl_Position.x *= u_scaleX;
  gl_Position.y *= u_scaleY;
  gl_Position.z = gl_Position.z * 2.0 - gl_Position.w;
}
