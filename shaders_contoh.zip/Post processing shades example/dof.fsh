#if __VERSION__ >= 130
#define varying in
#define texture2D texture
#define gl_FragColor fragColor
out vec4 fragColor;
#endif

#ifdef GL_ES
precision highp float;
precision highp int;
#endif

uniform sampler2D sampler0;
uniform sampler2D sampler1;
uniform sampler2D sampler2;
uniform vec2 u_texelDelta;
uniform vec4 u_setting;

varying vec2 v_texcoord0;

const float DEPTH_POW = 10.0;
const float EDGE_FEATHER = 0.02;

float getDepth(vec2 uv) {
	float d = 1.0 - pow(clamp(texture2D(sampler2, uv).r, 0.0, 1.0), DEPTH_POW);
	if (u_setting.w > 0.5 && u_setting.w < 1.5)
		d = 1.0 - d;
	return d;
}

float getDepthSmooth(vec2 uv) {
	vec2 o = u_texelDelta * 2.0;
	float d = getDepth(uv);
	d += getDepth(uv + vec2(o.x, 0.0));
	d += getDepth(uv - vec2(o.x, 0.0));
	d += getDepth(uv + vec2(0.0, o.y));
	d += getDepth(uv - vec2(0.0, o.y));
	return d * 0.2;
}

float cocFromDepth(float d) {
	float range = max(u_setting.y, 0.0001);
	float dist = max((d - u_setting.x) - range * 0.25, 0.0);
	return smoothstep(0.0, 1.0, clamp(dist / range, 0.0, 1.0));
}

void main() {
	vec2 uv = v_texcoord0;
	uv.y = 1.0 - uv.y;
	vec4 center = texture2D(sampler1, uv);
	float d = getDepthSmooth(uv);

	if (u_setting.w > 1.5) {
		gl_FragColor = vec4(vec3(d), 1.0);
		return;
	}

	float maxR = u_setting.z;
	float cocC = cocFromDepth(d);
	if (maxR <= 0.0 || cocC < 0.01) {
		gl_FragColor = center;
		return;
	}

	float edge = smoothstep(0.0, EDGE_FEATHER, uv.x) * smoothstep(0.0, EDGE_FEATHER, 1.0 - uv.x);
	float n = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
	float rot = n * 6.2831853;

	const int TAPS = 24;
	const float GOLDEN = 2.39996323;
	float radius = cocC * maxR * edge;

	vec3 sum = center.rgb;
	float wsum = 1.0;
	for (int i = 0; i < TAPS; i++) {
		float fi = float(i) + 0.5;
		float r = sqrt(fi / float(TAPS)) * radius;
		float a = fi * GOLDEN + rot;
		vec2 suv = uv + vec2(cos(a), sin(a)) * r * u_texelDelta;
		float cs = cocFromDepth(getDepth(suv));
		float w = clamp(cs / max(cocC, 0.001), 0.0, 1.0);
		sum += texture2D(sampler0, suv).rgb * w;
		wsum += w;
	}
	gl_FragColor = vec4(sum / wsum, center.a);
}