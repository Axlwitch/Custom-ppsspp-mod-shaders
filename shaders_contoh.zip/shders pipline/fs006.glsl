// efek emisif dengan u_time

#version 320 es
#extension GL_EXT_shader_framebuffer_fetch : require
#define DISCARD discard
precision lowp float;
precision highp int;
#define splat3(x) vec3(x)
#define mul(x, y) ((x) * (y))
uniform sampler2D tex;
uniform vec2 u_texNoAlphaMul;
in lowp vec4 v_color0;
uniform vec3 u_fogcolor;
in highp float v_fogdepth;
in highp vec3 v_texcoord;
in highp vec4 v_1;
in highp vec4 v_2;
in highp vec4 v_3;
in highp vec4 v_4;
flat in mediump int flag;
uniform highp float u_time;
uniform highp float u_near;
uniform highp float u_far;
highp vec3 getFxNormal() {
  highp vec3 nV = cross(dFdx(v_3.xyz), dFdy(v_3.xyz));
  if (flag == 1) {
    highp float l1 = dot(v_1.xyz, v_1.xyz);
    return l1 > 0.0 ? v_1.xyz * inversesqrt(l1) : vec3(0.0, 0.0, 1.0);
  }
  if (dot(nV, v_3.xyz) > 0.0) nV = -nV;
  highp float l2 = dot(nV, nV);
  return l2 > 0.0 ? nV * inversesqrt(l2) : vec3(0.0, 0.0, 1.0);
}
highp float getFarBlur() {
  if (flag != 2) return 0.0;
  return smoothstep(u_near, u_far, abs(v_3.z));
}
out vec4 fragColor0;

#define TEXTURE t

#define BASE_COLOR (TEXTURE.rgb * v_color0.rgb)
#define CLARIFIED_BASE clamp(((BASE_COLOR - 0.5) * 1.08) + 0.5, 0.0, 1.0)
#define BOOSTED_BASE (CLARIFIED_BASE * vec3(1.04, 1.03, 1.0))

#define LUMINANCE dot(TEXTURE.rgb, vec3(0.2126, 0.7152, 0.0722))
#define DARK_MASK (1.0 - smoothstep(0.02, 0.25, LUMINANCE))

#define t_anim (u_time * 0.6)
#define PULSE pow(abs(sin(t_anim)), 1.5)

#define SHIFT_FACTOR smoothstep(0.7, 0.95, PULSE)
#define DYNAMIC_EMISSION_COLOR mix(vec3(0.1, 0.8, 0.9), vec3(0.95, 0.15, 0.1), SHIFT_FACTOR)

#define CYAN_PULSE (DYNAMIC_EMISSION_COLOR * (0.05 + 0.95 * PULSE) * DARK_MASK * 2.2)

#define FINAL_COLOR clamp(BOOSTED_BASE + CYAN_PULSE, 0.0, 1.0)
#define GAMMA_CORRECTION pow(FINAL_COLOR, vec3(1.0 / 0.9))

void main() {
  vec2 uv = v_texcoord.xy;
  highp vec2 dx = dFdx(uv);
  highp vec2 dy = dFdy(uv);
  vec4 t = texture(tex, uv);
  highp float coc = getFarBlur();
  if (coc > 0.30) {
    highp float r = coc * 8.0;
    highp float n = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    highp float a = n * 6.2831853;
    highp vec2 c = vec2(cos(a), sin(a)) * r;
    highp vec2 s = vec2(-c.y, c.x);
    highp vec2 u1 = dx * c.x + dy * c.y;
    highp vec2 u2 = dx * s.x + dy * s.y;
    highp vec2 gx = dx * (1.0 + r * 0.5);
    highp vec2 gy = dy * (1.0 + r * 0.5);
    t = 0.2 * t
      + 0.2 * textureGrad(tex, uv + u1, gx, gy)
      + 0.2 * textureGrad(tex, uv - u1, gx, gy)
      + 0.2 * textureGrad(tex, uv + u2, gx, gy)
      + 0.2 * textureGrad(tex, uv - u2, gx, gy);
  }

  vec4 p = v_color0;
  t.a = max(t.a, u_texNoAlphaMul.x);
  vec4 v = p * t;
  v.rgb = clamp(v.rgb * u_texNoAlphaMul.y, 0.0, 1.0);

  if (flag == 1) {
    v.rgb = GAMMA_CORRECTION;
  }

  float fogCoef = clamp(v_fogdepth, 0.0, 1.0);
  v.rgb = mix(u_fogcolor, v.rgb, fogCoef);
  fragColor0 = v;
}


// anisotropric filtering dengan blur


#version 320 es
#extension GL_EXT_shader_framebuffer_fetch : require
#define DISCARD discard
precision lowp float;
precision highp int;
#define splat3(x) vec3(x)
#define mul(x, y) ((x) * (y))
uniform sampler2D tex;
uniform vec2 u_texNoAlphaMul;
in lowp vec4 v_color0;
uniform vec3 u_fogcolor;
in highp float v_fogdepth;
in highp vec3 v_texcoord;
in highp vec4 v_1;
in highp vec4 v_2;
in highp vec4 v_3;
in highp vec4 v_4;
flat in mediump int flag;
uniform highp float u_time;
uniform highp float u_near;
uniform highp float u_far;
highp vec3 getFxNormal() {
  highp vec3 nV = cross(dFdx(v_3.xyz), dFdy(v_3.xyz));
  if (flag == 1) {
    highp float l1 = dot(v_1.xyz, v_1.xyz);
    return l1 > 0.0 ? v_1.xyz * inversesqrt(l1) : vec3(0.0, 0.0, 1.0);
  }
  if (dot(nV, v_3.xyz) > 0.0) nV = -nV;
  highp float l2 = dot(nV, nV);
  return l2 > 0.0 ? nV * inversesqrt(l2) : vec3(0.0, 0.0, 1.0);
}
highp float getFarBlur() {
  if (flag != 2) return 0.0;
  return smoothstep(u_near, u_far, abs(v_3.z));
}
out vec4 fragColor0;

#define TEXTURE t

#define BASE_COLOR (TEXTURE.rgb * v_color0.rgb)
#define CLARIFIED_BASE clamp(((BASE_COLOR - 0.5) * 1.08) + 0.5, 0.0, 1.0)
#define BOOSTED_BASE (CLARIFIED_BASE * vec3(1.04, 1.03, 1.0))

#define LUMINANCE dot(TEXTURE.rgb, vec3(0.2126, 0.7152, 0.0722))
#define DARK_MASK (1.0 - smoothstep(0.02, 0.25, LUMINANCE))

#define t_anim (u_time * 0.6)
#define PULSE pow(abs(sin(t_anim)), 1.5)

#define SHIFT_FACTOR smoothstep(0.7, 0.95, PULSE)
#define DYNAMIC_EMISSION_COLOR mix(vec3(0.1, 0.8, 0.9), vec3(0.95, 0.15, 0.1), SHIFT_FACTOR)

#define CYAN_PULSE (DYNAMIC_EMISSION_COLOR * (0.05 + 0.95 * PULSE) * DARK_MASK * 2.2)

#define FINAL_COLOR clamp(BOOSTED_BASE + CYAN_PULSE, 0.0, 1.0)
#define GAMMA_CORRECTION pow(FINAL_COLOR, vec3(1.0 / 0.9))

void main() {
  vec2 uv = v_texcoord.xy;
  highp vec2 dx = dFdx(uv);
  highp vec2 dy = dFdy(uv);
  vec4 t = texture(tex, uv);
  highp float coc = getFarBlur();
  if (coc > 0.30) {
    highp float r = coc * 8.0;
    highp float n = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    highp float a = n * 6.2831853;
    highp vec2 c = vec2(cos(a), sin(a)) * r;
    highp vec2 s = vec2(-c.y, c.x);
    highp vec2 u1 = dx * c.x + dy * c.y;
    highp vec2 u2 = dx * s.x + dy * s.y;
    highp vec2 gx = dx * (1.0 + r * 0.5);
    highp vec2 gy = dy * (1.0 + r * 0.5);
    t = 0.2 * t
      + 0.2 * textureGrad(tex, uv + u1, gx, gy)
      + 0.2 * textureGrad(tex, uv - u1, gx, gy)
      + 0.2 * textureGrad(tex, uv + u2, gx, gy)
      + 0.2 * textureGrad(tex, uv - u2, gx, gy);
  }

  vec4 p = v_color0;
  t.a = max(t.a, u_texNoAlphaMul.x);
  vec4 v = p * t;
  v.rgb = clamp(v.rgb * u_texNoAlphaMul.y, 0.0, 1.0);

  if (coc > 0.0) {
    float g = dot(v.rgb, vec3(0.2126, 0.7152, 0.0722));
    vec3 desat = mix(v.rgb, vec3(g), coc * 0.2);
    vec3 haze = mix(vec3(g), vec3(0.60, 0.66, 0.74), 0.5);
    v.rgb = mix(desat, haze, coc * 0.25);
  }

  if (flag == 1) {
    v.rgb = GAMMA_CORRECTION;
  }

  float fogCoef = clamp(v_fogdepth, 0.0, 1.0);
  v.rgb = mix(u_fogcolor, v.rgb, fogCoef);
  fragColor0 = v;
}